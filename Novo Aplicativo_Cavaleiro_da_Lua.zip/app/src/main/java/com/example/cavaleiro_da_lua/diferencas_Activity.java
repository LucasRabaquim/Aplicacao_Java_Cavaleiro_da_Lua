package com.example.cavaleiro_da_lua;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class diferencas_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diferencas);
    }
}